Space Pixl press kit

Naming: PIXL is always written in capitals and always white. The product word
takes the product's colour (PLAYROOM violet, SPACE blue); the engine's stays grey.

Please don't recolour, stretch, rotate, outline or add effects to the marks, and
keep clear space around them of at least a quarter of the mark's width.

The SVGs are the masters; the PNGs are for places that can't take SVG.
Questions: hello@pixlfoundation.com
