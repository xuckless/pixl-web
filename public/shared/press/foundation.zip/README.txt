PIXL Foundation press kit

Naming: PIXL is always written in capitals and always white. The product word
takes the product's colour (PLAYROOM violet, SPACE blue); the engine's stays grey.
The Foundation mark is the word PIXL drawn on a seven-row pixel grid. Below 60 px
wide, use the P. Render both at whole pixels per cell so no edge is blurred.

Please don't recolour, stretch, rotate, outline or add effects to the marks, and
keep clear space around them of at least a quarter of the mark's width.

The SVGs are the masters; the PNGs are for places that can't take SVG.
Questions: hello@pixlfoundation.com
